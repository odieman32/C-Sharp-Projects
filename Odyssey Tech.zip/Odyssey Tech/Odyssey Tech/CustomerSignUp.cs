﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odyssey_Tech
{
    public partial class CustomerSignUp : Form
    {
        private SQLControl sql = new SQLControl();
        public CustomerSignUp()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) ||
                string.IsNullOrEmpty(textBox2.Text) ||
                string.IsNullOrEmpty(textBox3.Text) ||
                string.IsNullOrEmpty(textBox4.Text) ||
                string.IsNullOrEmpty(textBox5.Text))
            {
                MessageBox.Show("Please fill in all fields");
                    return; 
            }

            //Add customer to the database
            sql.AddParam("@firstN", textBox1.Text.Trim());
            sql.AddParam("@lastN", textBox2.Text.Trim());
            sql.AddParam("@email", textBox3.Text.Trim());
            sql.AddParam("@phoneNum", textBox4.Text.Trim());
            sql.AddParam("@password", textBox5.Text.Trim());
            //Execute query
            sql.ExecQuery("INSERT INTO Customers (firstN, lastN, email, phoneNum, password) " +
                          "VALUES (@firstN, @lastN, @email, @phoneNum, @password)");

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"An error occured: {sql.Exception}");
                return;
            }

            MessageBox.Show($"Registration successful! You can now sign in");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CustomerSignIn customer = new CustomerSignIn();
            customer.Show();
            this.Close();
        }
    }
}
