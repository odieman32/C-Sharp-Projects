﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odyssey_Tech
{
    public partial class CustomerPage : Form
    {
        private SQLControl sql = new SQLControl();
        private int CustomerID;
        private string CustomerEmail;
        public CustomerPage(string email)
        {
            InitializeComponent();

            CustomerEmail = email; // Save the email for session tracking

            // Retrieve CustomerID based on the email
            sql.AddParam("@Email", CustomerEmail);
            sql.ExecQuery("SELECT customer_id FROM Customers WHERE email = @Email");

            if (!string.IsNullOrEmpty(sql.Exception) || sql.SQLDS.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show($"Error loading customer data: {sql.Exception}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            CustomerID = Convert.ToInt32(sql.SQLDS.Tables[0].Rows[0]["customer_id"]); // Retrieve the CustomerID

            LoadProducts();
            LoadCart();
        }

        //Load Products into the data grid
        private void LoadProducts()
        {
            // Step 1: Fetch customer's most purchased categories
            sql.AddParam("@CustomerID", CustomerID);
            sql.ExecQuery("SELECT TOP 3 p.category, COUNT(p.category) AS CategoryCount " +
                          "FROM Purchases pu " +
                          "JOIN Products p ON pu.product_id = p.product_id " +
                          "WHERE pu.customer_id = @CustomerID " +
                          "GROUP BY p.category " +
                          "ORDER BY CategoryCount DESC");

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Error fetching top categories: {sql.Exception}");
                return;
            }

            // Get the top categories
            var topCategories = new List<string>();
            foreach (DataRow row in sql.SQLDS.Tables[0].Rows)
            {
                topCategories.Add(row["category"].ToString());
            }

            // Step 2: Build the query based on whether we have top categories
            string query;

            if (topCategories.Count > 0)
            {
                // Prioritize products from top categories
                string formattedCategories = string.Join(",", topCategories.Select(cat => $"'{cat}'"));
                query = $"SELECT product_id, productName, price, category, " +
                        $"CASE WHEN category IN ({formattedCategories}) THEN 1 ELSE 2 END AS CategoryPriority, " +
                        "ROW_NUMBER() OVER (PARTITION BY category ORDER BY productName) AS RowNum " +
                        "FROM Products " +
                        "ORDER BY CategoryPriority, RowNum";
            }
            else
            {
                // No priority, just show all products
                query = "SELECT product_id, productName, price, category, " +
                        "ROW_NUMBER() OVER (PARTITION BY category ORDER BY productName) AS RowNum " +
                        "FROM Products " +
                        "ORDER BY RowNum";
            }

            // Step 3: Execute the query
            sql.ExecQuery(query);

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Error loading products: {sql.Exception}");
                return;
            }

            // Step 4: Bind the products to the DataGridView
            dataGridView1.DataSource = sql.SQLDS.Tables[0];
        }

        //Load the customer's cart from the Cart table
        private void LoadCart()
        {
            sql.AddParam("@CustomerID", CustomerID);
            sql.ExecQuery("SELECT c.CartID, p.productName, p.price, c.Quantity " +
                "FROM Cart c " +
                "JOIN Products p ON c.product_id = p.product_id " +
                "WHERE c.customer_id = @CustomerID");

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Error loading cart: {sql.Exception}");
                return;
            }

            dataGridView2.DataSource = sql.SQLDS.Tables[0]; //Bind the cart list to the data grid
        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a product to add to the cart.");
                return;
            }

            // Get selected product details
            var row = dataGridView1.SelectedRows[0];
            int productID = Convert.ToInt32(row.Cells["product_id"].Value);

            // Check if the product is already in the cart
            sql.AddParam("@CustomerID", CustomerID);
            sql.AddParam("@ProductID", productID);
            sql.ExecQuery("SELECT * FROM Cart WHERE customer_id = @CustomerID AND product_id = @ProductID");

            if (sql.RecordCount > 0)
            {
                // Update quantity if already in cart
                sql.AddParam("@CustomerID", CustomerID);
                sql.AddParam("@ProductID", productID);
                sql.AddParam("@Quantity", 1); // Increment by 1
                sql.ExecQuery("UPDATE Cart SET Quantity = Quantity + @Quantity " +
                              "WHERE customer_id = @CustomerID AND product_id = @ProductID");
            }
            else
            {
                // Add new item to the cart
                sql.AddParam("@CustomerID", CustomerID);
                sql.AddParam("@ProductID", productID);
                sql.AddParam("@Quantity", 1); // Default quantity is 1
                sql.ExecQuery("INSERT INTO Cart (customer_id, product_id, Quantity) " +
                              "VALUES (@CustomerID, @ProductID, @Quantity)");
            }

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Error updating cart: {sql.Exception}");
                return;
            }

            MessageBox.Show("Product added to cart!");
            LoadCart(); // Refresh cart data
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Load all items in the customer's cart
            sql.AddParam("@CustomerID", CustomerID);
            sql.ExecQuery("SELECT product_id, Quantity FROM Cart WHERE customer_id = @CustomerID");

            if (sql.RecordCount == 0)
            {
                MessageBox.Show("Your cart is empty.");
                return;
            }

            foreach (DataRow row in sql.SQLDS.Tables[0].Rows)
            {
                int productID = Convert.ToInt32(row["product_id"]);
                int quantity = Convert.ToInt32(row["Quantity"]);

                // Insert purchase record
                sql.AddParam("@ProductID", productID);
                sql.AddParam("@Quantity", quantity);
                sql.AddParam("@CustomerID", CustomerID);
                sql.ExecQuery("INSERT INTO Purchases (customer_id, product_id, Quantity, PurchaseDate) " +
                              "VALUES (@CustomerID, @ProductID, @Quantity, GETDATE())");

                if (!string.IsNullOrEmpty(sql.Exception))
                {
                    MessageBox.Show($"Error processing purchase: {sql.Exception}");
                    return;
                }
            }

            // Clear the cart
            sql.AddParam("@CustomerID", CustomerID);
            sql.ExecQuery("DELETE FROM Cart WHERE customer_id = @CustomerID");

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Error clearing cart: {sql.Exception}");
                return;
            }

            MessageBox.Show("Purchase completed successfully!");
            LoadCart(); // Refresh cart data
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Confirm the action with the user
            var result = MessageBox.Show("Are you sure you want to clear your cart?",
                                         "Clear Cart",
                                         MessageBoxButtons.YesNo,
                                         MessageBoxIcon.Warning);

            if (result == DialogResult.No)
                return;

            // Clear all items in the customer's cart
            sql.AddParam("@CustomerID", CustomerID);
            sql.ExecQuery("DELETE FROM Cart WHERE customer_id = @CustomerID");

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Error clearing cart: {sql.Exception}");
                return;
            }

            MessageBox.Show("Your cart has been cleared!");
            LoadCart(); // Refresh cart data
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.Show();
            this.Close();
        }
    }
}
