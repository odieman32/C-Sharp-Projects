﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odyssey_Tech
{
    public partial class EmployeeLogin : Form
    {
        private SQLControl sql = new SQLControl();
        public EmployeeLogin()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Get the user input
            string username = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();
            

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) )
            {
                MessageBox.Show("Please enter both username and password");
                return;
            }

            //SQL query to check employee login
            sql.AddParam("@username", username);
            sql.AddParam("@password", password);
            sql.ExecQuery("SELECT * FROM Employees WHERE username = @username AND password = @password");

            //Exceptions and error handling
            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Database error: {sql.Exception}");
                return;
            }
            if (sql.RecordCount > 0)
            {
                //Login Success
                MessageBox.Show("Login Successful!");
                this.Hide();

                //Open Employee Page
                EmployeePage employeePage = new EmployeePage();
                employeePage.Show();

                this.Close();
            }
            else
            {
                //Login Failed
                MessageBox.Show("Invalid username or password");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.Show();
            this.Close();
        }
    }
}
