﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Odyssey_Tech
{
    public class SQLControl
    {
        private SqlConnection SQLCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\C# Class\Odyssey Tech\Odyssey Tech\OdysseyTechDB.mdf"";Integrated Security=True");

        private SqlCommand SQLCmd;

        // DB DATA
        public SqlDataAdapter SQLDA;
        public DataSet SQLDS;

        // QUERY PARAMETERS
        public List<SqlParameter> Params = new List<SqlParameter>();

        // QUERY STATISTICS
        public int RecordCount { get; private set; }
        public string Exception { get; private set; }

        public SQLControl() { }

        // ALLOW CONNECTION STRING OVERRIDE
        public SQLControl(string connectionString)
        {
            SQLCon = new SqlConnection(connectionString);
        }

        // EXECUTE QUERY METHOD
        public void ExecQuery(string query)
        {
            // RESET QUERY STATS
            RecordCount = 0;
            Exception = "";

            try
            {
                SQLCon.Open();

                // CREATE DB COMMAND
                SQLCmd = new SqlCommand(query, SQLCon);

                // LOAD PARAMETERS INTO COMMAND
                Params.ForEach(param => SQLCmd.Parameters.Add(param));

                // CLEAR PARAMETER LIST
                Params.Clear();

                // EXECUTE COMMAND AND FILL DATASET
                SQLDS = new DataSet();
                SQLDA = new SqlDataAdapter(SQLCmd);
                RecordCount = SQLDA.Fill(SQLDS);
            }
            catch (Exception ex)
            {
                // CAPTURE ERRORS
                Exception = ex.Message;
            }
            finally
            {
                // CLOSE CONNECTION
                if (SQLCon.State == ConnectionState.Open)
                    SQLCon.Close();
            }
        }

        // ADD PARAMETER METHOD
        public void AddParam(string name, object value)
        {
            SqlParameter newParam = new SqlParameter(name, value);
            Params.Add(newParam);
        }
    }
}
