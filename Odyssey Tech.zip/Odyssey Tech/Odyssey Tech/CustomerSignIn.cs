﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odyssey_Tech
{
    public partial class CustomerSignIn : Form
    {
        private SQLControl sql = new SQLControl();
        public CustomerSignIn()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Get the email and password from text boxes
            string email = textBox3.Text.Trim();
            string password = textBox5.Text.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please fill in both fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate user credentials
            if (ValidateCustomer(email, password))
            {
                // Open the Products Page and pass the customer's email
                CustomerPage productsPage = new CustomerPage(email); // Pass the email for session tracking
                this.Hide();
                productsPage.Show();
            }
            else
            {
                MessageBox.Show("Invalid email or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private bool ValidateCustomer(string email, string password)
        {
            sql.AddParam("@Email", email);
            sql.AddParam("@Password", password);

            // Query the Customers table for email and password
            sql.ExecQuery("SELECT * FROM Customers WHERE email = @Email AND password = @Password");

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Error validating customer: {sql.Exception}");
                return false;
            }

            // If a record is found, credentials are valid
            return sql.SQLDS.Tables[0].Rows.Count > 0;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //Open the Customer Sign Up Form
            CustomerSignUp customerSignUp = new CustomerSignUp();
            customerSignUp.ShowDialog();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.Show();
            this.Close();
        }
    }
}
