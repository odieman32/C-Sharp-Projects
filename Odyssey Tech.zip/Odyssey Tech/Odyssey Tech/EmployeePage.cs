﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odyssey_Tech
{
    public partial class EmployeePage : Form
    {
        private SQLControl sql = new SQLControl();
        public EmployeePage()
        {
            InitializeComponent();
            LoadCustomers();
        }

        //Loads all customers
        private void LoadCustomers()
        {
            sql.ExecQuery("SELECT * FROM Customers");

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Error loading customer: {sql.Exception}");
                return;
            }
            //Binds the data to the data grid
            dataGridView1.DataSource = sql.SQLDS.Tables[0]; 
        }

        //method to search for customers
        private void SearchCustomers(string query)
        {
            sql.AddParam("@query", $"%{query}%");
            sql.ExecQuery("SELECT * FROM Customers WHERE lastN LIKE @query OR email LIKE @query OR phoneNum LIKE @query");

            if (!string.IsNullOrEmpty(sql.Exception))
            {
                MessageBox.Show($"Error searching customers: {sql.Exception}");
                return;
            }
            //Binds the search results to data grid
            dataGridView1.DataSource = sql.SQLDS.Tables[0];
        }

        private void DeleteCustomer(int customerId)
        {
            try
            {
                // Prepare the DELETE query
                sql.AddParam("@CustomerID", customerId);
                sql.ExecQuery("DELETE FROM Customers WHERE customer_id = @CustomerID");

                if (!string.IsNullOrEmpty(sql.Exception))
                {
                    MessageBox.Show($"Error deleting customer: {sql.Exception}");
                    return;
                }

                MessageBox.Show("Customer deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Refresh the customer list after deletion
                LoadCustomers();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unexpected error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void EmployeePage_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'odysseyTechDBDataSet.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.odysseyTechDBDataSet.Customers);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(query))
            {
                MessageBox.Show("Please enter a search term.");
                return;
            }

            SearchCustomers(query);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadCustomers(); //refresh data grid
            textBox1.Clear(); //clear search
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close(); //close employee page
            //open login page
            EmployeeLogin employeeLogin = new EmployeeLogin();
            employeeLogin.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Assuming the first column contains the Customer ID
                int customerId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);

                // Confirm deletion with the user
                var confirmResult = MessageBox.Show(
                    "Are you sure you want to delete this customer?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (confirmResult == DialogResult.Yes)
                {
                    DeleteCustomer(customerId);
                }
            }
            else
            {
                MessageBox.Show("Please select a customer to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

